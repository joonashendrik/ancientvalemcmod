package net.mcreator.forgottenvale.procedures;

import net.minecraft.world.IWorld;
import net.minecraft.util.math.BlockPos;

import net.mcreator.forgottenvale.block.AncientGrassBlockBlock;
import net.mcreator.forgottenvale.ForgottenValeMod;

import java.util.Map;

public class AncientGrassBlockUpdateTickProcedure {

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				ForgottenValeMod.LOGGER.warn("Failed to load dependency world for procedure AncientGrassBlockUpdateTick!");
			return;
		}
		if (dependencies.get("x") == null) {
			if (!dependencies.containsKey("x"))
				ForgottenValeMod.LOGGER.warn("Failed to load dependency x for procedure AncientGrassBlockUpdateTick!");
			return;
		}
		if (dependencies.get("y") == null) {
			if (!dependencies.containsKey("y"))
				ForgottenValeMod.LOGGER.warn("Failed to load dependency y for procedure AncientGrassBlockUpdateTick!");
			return;
		}
		if (dependencies.get("z") == null) {
			if (!dependencies.containsKey("z"))
				ForgottenValeMod.LOGGER.warn("Failed to load dependency z for procedure AncientGrassBlockUpdateTick!");
			return;
		}
		IWorld world = (IWorld) dependencies.get("world");
		double x = dependencies.get("x") instanceof Integer ? (int) dependencies.get("x") : (double) dependencies.get("x");
		double y = dependencies.get("y") instanceof Integer ? (int) dependencies.get("y") : (double) dependencies.get("y");
		double z = dependencies.get("z") instanceof Integer ? (int) dependencies.get("z") : (double) dependencies.get("z");
		if (Math.random() < 0.7) {
			if (world.isAirBlock(new BlockPos((int) x, (int) (y + 1), (int) z))
					&& ((world.getBlockState(new BlockPos((int) (x + 1), (int) y, (int) z))).getBlock() == AncientGrassBlockBlock.block
							|| (world.getBlockState(new BlockPos((int) (x - 1), (int) y, (int) z))).getBlock() == AncientGrassBlockBlock.block
							|| (world.getBlockState(new BlockPos((int) x, (int) y, (int) (z - 1)))).getBlock() == AncientGrassBlockBlock.block
							|| (world.getBlockState(new BlockPos((int) x, (int) y, (int) (z + 1)))).getBlock() == AncientGrassBlockBlock.block
							|| (world.getBlockState(new BlockPos((int) (x + 1), (int) (y + 1), (int) z))).getBlock() == AncientGrassBlockBlock.block
							|| (world.getBlockState(new BlockPos((int) (x - 1), (int) (y + 1), (int) z))).getBlock() == AncientGrassBlockBlock.block
							|| (world.getBlockState(new BlockPos((int) (x + 1), (int) (y - 1), (int) z))).getBlock() == AncientGrassBlockBlock.block
							|| (world.getBlockState(new BlockPos((int) (x - 1), (int) (y - 1), (int) z))).getBlock() == AncientGrassBlockBlock.block
							|| (world.getBlockState(new BlockPos((int) x, (int) (y + 1), (int) (z + 1)))).getBlock() == AncientGrassBlockBlock.block
							|| (world.getBlockState(new BlockPos((int) x, (int) (y + 1), (int) (z - 1)))).getBlock() == AncientGrassBlockBlock.block
							|| (world.getBlockState(new BlockPos((int) x, (int) (y - 1), (int) (z + 1)))).getBlock() == AncientGrassBlockBlock.block
							|| (world.getBlockState(new BlockPos((int) x, (int) (y - 1), (int) (z - 1))))
									.getBlock() == AncientGrassBlockBlock.block)) {
				world.setBlockState(new BlockPos((int) x, (int) y, (int) z), AncientGrassBlockBlock.block.getDefaultState(), 3);
			}
		}
	}
}
